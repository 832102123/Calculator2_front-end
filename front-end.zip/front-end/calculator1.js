
        var input = document.querySelector('.input');
        var output = document.querySelector('.output');
        var calculateButtons = document.querySelectorAll('.calculate');
        // 绑定计算按钮点击事件
        for (var i = 0; i < calculateButtons.length; i++) {
            calculateButtons[i].addEventListener('click', function (e) {
                var current = input.value;
                var result = '';
                try {
                    // 计算输入表达式的结果
	    					 var current = input.value
                        .replace(/×/g, '*')
                        .replace(/÷/g, '/')
                        .replace(/sin/g, 'Math.sin')
                        .replace(/cos/g, 'Math.cos')
                        .replace(/tan/g, 'Math.tan');

                    // 使用 eval() 对计算表达式进行求值
                    var result = eval(current);
                    var input1 = input.value;
                    var input2 = result;
              
                    var xhr = new XMLHttpRequest();
                    xhr.open('POST', 'api.php', true);
                    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
              
                    xhr.onreadystatechange = function() {
                      if (xhr.readyState === 4 && xhr.status === 200) {
                        // 请求成功，可以处理响应数据
                        console.log(xhr.responseText);
                      }
                    };
              
                    var formData = 'data1=' + encodeURIComponent(input1) + '&data2=' + encodeURIComponent(input2);
                    xhr.send(formData);
                    console.log(result);
                } catch (e) {
                    result = 'Error!';
                }
                num=0;
                hisButtonCheck();
                input.value = result;
                
            });
        }
			
        var numButtons = document.querySelectorAll('.num');
        for (var i = 0; i < numButtons.length; i++) {
            numButtons[i].addEventListener('click', function (e) {
                var buttonValue = this.textContent;
                if (buttonValue === 'AC') {
                    input.value = '';
                } else if (buttonValue === 'del') {
                    input.value = input.value.slice(0, -1);
                } else {
                    input.value += buttonValue;
                }
  
            });
        }
        var num=0;
        var hisFonding=0;
        var numButtons = document.querySelectorAll('.his');
        for (var i = 0; i < numButtons.length; i++) {
            numButtons[i].addEventListener('click', function (e) {
                if(hisFonding==1){
                    return;
                }
                hisFonding=1;                
                
                setButtonS(1,0);
                var buttonValue = this.textContent;
                if (buttonValue === '←') {
                    if(num>0){
                        num-=1;
                    }                    
                    console.log(num+"1")
                } else if (buttonValue === 'ans') {
                    if(num<10){
                        num+=1;
                    }         
                    console.log(num+"2")
                }
                if(0<num && num<11){
                    // 创建XMLHttpRequest对象
                    var xhr = new XMLHttpRequest();

                    // 设置请求方法和URL
                    xhr.open('GET', 'api.php?num='+num, true);

                    // 设置响应类型为JSON
                    xhr.responseType = 'json';

                    // 监听请求完成事件
                    xhr.onload = function() {
                        if (xhr.status === 200) {
                            // 请求成功
                            var responseData = xhr.response;
                            // 在这里处理返回的JSON数据
                            console.log(responseData);
                            if(responseData==0){                                
                                setButtonS(1,0);
                                
                                hisFonding=0;
                                return;
                            }
                            document.querySelector('.input').value=responseData[0].cur;
                            setTimeout(function(){
                                document.querySelector('.input').value=responseData[0].res;
                                hisFonding=0;
                                hisButtonCheck();
                            },1000);
                            
                        } else {
                            // 请求失败
                            console.log('请求失败：' + xhr.status);
                        }
                    };

                    // 发送请求
                    xhr.send();
                }else if(num==0){
                    document.querySelector('.input').value='';                    
                    hisFonding=0;
                    hisButtonCheck();
                }

  
            });
        }
        function hisButtonCheck(){
            if(num>=10){
                setButtonS(1,0);
                
            }else if(num<=0){
                
                setButtonS(1,1);
            }else{
                
                setButtonS(1,1);
            }
        }
        function setButtonS(i,state){
            // 获取所有class为his的按钮
            var buttons = document.getElementsByClassName('his');

            // 获取第i个按钮并修改它的属性或样式
            var secondButton = buttons[i-1];
            // 在此处添加您想要的操作，例如修改属性或样式
            secondButton.disabled = !state; // 禁用按钮
        }
